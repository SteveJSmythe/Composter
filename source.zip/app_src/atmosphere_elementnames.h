
#ifndef ATMO_ELEMENT_NAMES_H
#define ATMO_ELEMENT_NAMES_H

#ifdef __cplusplus
	extern "C"{
#endif

#define ATMO_ELEMENT_NAME(ELEMENT) ATMO_ ## ELEMENT ## _NAME

#define ATMO_Interval_NAME "Interval"
#define ATMO_MCP9808Temperature_NAME "MCP9808Temperature"
#define ATMO_DebugPrint_NAME "DebugPrint"
#define ATMO_MCP9808_NAME "MCP9808"

#ifdef __cplusplus
}
#endif
#endif
