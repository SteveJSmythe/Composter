
#ifndef ATMO_INTERRUPTS_HANDLER_H
#define ATMO_INTERRUPTS_HANDLER_H

#ifdef __cplusplus
	extern "C"{
#endif

#include "../atmo/core.h"
#define ATMO_INTERRUPT(ELEMENT, NAME) ATMO_ ## ELEMENT ## _INTERRUPT_  ## NAME

void ATMO_Interval_INTERRUPT_trigger(void *data);
void ATMO_Interval_INTERRUPT_setup(void *data);
void ATMO_Interval_INTERRUPT_interval(void *data);

void ATMO_MCP9808Temperature_INTERRUPT_trigger(void *data);
void ATMO_MCP9808Temperature_INTERRUPT_setup(void *data);
void ATMO_MCP9808Temperature_INTERRUPT_readAmbientTemperature(void *data);

void ATMO_DebugPrint_INTERRUPT_trigger(void *data);
void ATMO_DebugPrint_INTERRUPT_setup(void *data);
void ATMO_DebugPrint_INTERRUPT_print(void *data);

void ATMO_MCP9808_INTERRUPT_trigger(void *data);
void ATMO_MCP9808_INTERRUPT_setup(void *data);
void ATMO_MCP9808_INTERRUPT_setValue(void *data);
void ATMO_MCP9808_INTERRUPT_written(void *data);
void ATMO_MCP9808_INTERRUPT_subscibed(void *data);
void ATMO_MCP9808_INTERRUPT_unsubscribed(void *data);


#ifdef __cplusplus
}
#endif

#endif
