#include "atmosphere_elementSetup.h"

#ifdef __cplusplus
	extern "C"{
#endif

void ATMO_ElementSetup() {
	ATMO_Value_t inOutValue;
	ATMO_InitValue(&inOutValue);
	Interval_setup(&inOutValue, &inOutValue);
	MCP9808Temperature_setup(&inOutValue, &inOutValue);
	DebugPrint_setup(&inOutValue, &inOutValue);
	MCP9808_setup(&inOutValue, &inOutValue);
}

#ifdef __cplusplus
}
#endif
