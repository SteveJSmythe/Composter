
#ifndef ATMO_TRIGGER_HANDLER_H
#define ATMO_TRIGGER_HANDLER_H

#include "atmosphere_platform.h"
#include "../atmo/core.h"

#ifdef __cplusplus
	extern "C"{
#endif

#define ATMO_TRIGGER(ELEMENT, NAME) ATMO_ ## ELEMENT ## _TRIGGER_  ## NAME

void ATMO_TriggerHandler(unsigned int triggerHandleId, ATMO_Value_t *value);

#define ATMO_Interval_TRIGGER_triggered 0x1
#define ATMO_Interval_TRIGGER_interval 0x2
#define ATMO_MCP9808Temperature_TRIGGER_triggered 0x3
#define ATMO_MCP9808Temperature_TRIGGER_ambientTemperatureRead 0x4
#define ATMO_DebugPrint_TRIGGER_triggered 0x5
#define ATMO_DebugPrint_TRIGGER_printed 0x6
#define ATMO_MCP9808_TRIGGER_triggered 0x7
#define ATMO_MCP9808_TRIGGER_written 0x8
#define ATMO_MCP9808_TRIGGER_subscibed 0x9
#define ATMO_MCP9808_TRIGGER_unsubscribed 0xa
#ifdef __cplusplus
}
#endif
#endif
