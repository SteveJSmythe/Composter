#include "atmosphere_interruptsHandler.h"
#include "atmosphere_abilityHandler.h"


#ifdef __cplusplus
extern "C"{
#endif
void ATMO_Interval_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(Interval, trigger), (ATMO_Value_t *)data);
}
void ATMO_Interval_INTERRUPT_setup(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(Interval, setup), (ATMO_Value_t *)data);
}
void ATMO_Interval_INTERRUPT_interval(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(Interval, interval), (ATMO_Value_t *)data);
}
void ATMO_MCP9808Temperature_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(MCP9808Temperature, trigger), (ATMO_Value_t *)data);
}
void ATMO_MCP9808Temperature_INTERRUPT_setup(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(MCP9808Temperature, setup), (ATMO_Value_t *)data);
}
void ATMO_MCP9808Temperature_INTERRUPT_readAmbientTemperature(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(MCP9808Temperature, readAmbientTemperature), (ATMO_Value_t *)data);
}
void ATMO_DebugPrint_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(DebugPrint, trigger), (ATMO_Value_t *)data);
}
void ATMO_DebugPrint_INTERRUPT_setup(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(DebugPrint, setup), (ATMO_Value_t *)data);
}
void ATMO_DebugPrint_INTERRUPT_print(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(DebugPrint, print), (ATMO_Value_t *)data);
}
void ATMO_MCP9808_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(MCP9808, trigger), (ATMO_Value_t *)data);
}
void ATMO_MCP9808_INTERRUPT_setup(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(MCP9808, setup), (ATMO_Value_t *)data);
}
void ATMO_MCP9808_INTERRUPT_setValue(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(MCP9808, setValue), (ATMO_Value_t *)data);
}
void ATMO_MCP9808_INTERRUPT_written(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(MCP9808, written), (ATMO_Value_t *)data);
}
void ATMO_MCP9808_INTERRUPT_subscibed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(MCP9808, subscibed), (ATMO_Value_t *)data);
}
void ATMO_MCP9808_INTERRUPT_unsubscribed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(MCP9808, unsubscribed), (ATMO_Value_t *)data);
}

#ifdef __cplusplus
}
#endif
	