
#ifndef ATMO_ABILITY_HANDLER_H
#define ATMO_ABILITY_HANDLER_H

#include "atmosphere_platform.h"
#include "atmosphere_callbacks.h"

#include "../atmo/core.h"

#ifdef __cplusplus
	extern "C"{
#endif

#define ATMO_ABILITY(ELEMENT, NAME) ATMO_ ## ELEMENT ## _ABILITY_  ## NAME

void ATMO_AbilityHandler(unsigned int abilityHandleId, ATMO_Value_t *value);

#define ATMO_Interval_ABILITY_trigger 0x1
#define ATMO_Interval_ABILITY_setup 0x2
#define ATMO_Interval_ABILITY_interval 0x3
#define ATMO_MCP9808Temperature_ABILITY_trigger 0x4
#define ATMO_MCP9808Temperature_ABILITY_setup 0x5
#define ATMO_MCP9808Temperature_ABILITY_readAmbientTemperature 0x6
#define ATMO_DebugPrint_ABILITY_trigger 0x7
#define ATMO_DebugPrint_ABILITY_setup 0x8
#define ATMO_DebugPrint_ABILITY_print 0x9
#define ATMO_MCP9808_ABILITY_trigger 0xa
#define ATMO_MCP9808_ABILITY_setup 0xb
#define ATMO_MCP9808_ABILITY_setValue 0xc
#define ATMO_MCP9808_ABILITY_written 0xd
#define ATMO_MCP9808_ABILITY_subscibed 0xe
#define ATMO_MCP9808_ABILITY_unsubscribed 0xf
#ifdef __cplusplus
}
#endif
#endif
