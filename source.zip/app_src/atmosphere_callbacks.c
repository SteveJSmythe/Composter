#include "atmosphere_callbacks.h"

//HEADER START

//HEADER END

void ATMO_Setup() {

}


ATMO_Status_t Interval_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t Interval_setup(ATMO_Value_t *in, ATMO_Value_t *out) {

	ATMO_INTERVAL_Handle_t intervalHandle;
    ATMO_INTERVAL_AddAbilityInterval(
		ATMO_PROPERTY(Interval, instance), 
		ATMO_ABILITY(Interval, interval), 
		ATMO_PROPERTY(Interval, time), 
		&intervalHandle
	);
	
	return ATMO_Status_Success;
	
}


ATMO_Status_t Interval_interval(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t MCP9808Temperature_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t MCP9808Temperature_setup(ATMO_Value_t *in, ATMO_Value_t *out) {
    if (!ATMO_MCP9808_Init(ATMO_PROPERTY(MCP9808Temperature, i2cInstance), ATMO_PROPERTY(MCP9808Temperature, i2cAddress)))
    {
        return ATMO_Status_Fail;
    }
    return ATMO_Status_Success;
}


ATMO_Status_t MCP9808Temperature_readAmbientTemperature(ATMO_Value_t *in, ATMO_Value_t *out) {
    float temp = 0;

    if (!ATMO_MCP9808_ReadTemperature(&temp))
    {
        return ATMO_Status_Fail;
    }

    ATMO_CreateValueFloat(out, temp);
    return ATMO_Status_Success;
}


ATMO_Status_t DebugPrint_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t DebugPrint_setup(ATMO_Value_t *in, ATMO_Value_t *out) {

	return ATMO_Status_Success;
	
}


ATMO_Status_t DebugPrint_print(ATMO_Value_t *in, ATMO_Value_t *out) {

    if((in != NULL) && (in->type != ATMO_DATATYPE_VOID))
    {
        char str[256];
        unsigned int prependLen = strlen(ATMO_PROPERTY(DebugPrint, prepend));
        // If there's text to prepend, do that first
        if(prependLen > 0)
        {
            sprintf(str, "%s: ", ATMO_PROPERTY(DebugPrint, prepend));
            prependLen += 2; // Adding 2 chars for ": "
        }
        
        // Grab the string version of the input data, place it after the prepend text
        if(ATMO_GetString(in, str + prependLen, 256 - prependLen) == ATMO_Status_Success)
        {
            ATMO_PLATFORM_DebugPrint("%s\r\n", str);
        }
    }
    else
    {
        ATMO_PLATFORM_DebugPrint("%s\r\n", ATMO_PROPERTY(DebugPrint, prepend));
    }
    
    return ATMO_Status_Success;
    
}


ATMO_Status_t MCP9808_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t MCP9808_setup(ATMO_Value_t *in, ATMO_Value_t *out) {

	ATMO_BLE_GATTSAddService(
		ATMO_PROPERTY(MCP9808, instance),
		&ATMO_VARIABLE(MCP9808, bleServiceHandle), 
		ATMO_PROPERTY(MCP9808, bleServiceUuid));
	
	uint8_t property = 0;
	uint8_t permission = 0;
	
	property |= ATMO_PROPERTY(MCP9808, read) ? ATMO_BLE_Property_Read : 0;
	property |= ATMO_PROPERTY(MCP9808, write) ? ATMO_BLE_Property_Write : 0;
	property |= ATMO_PROPERTY(MCP9808, notify) ? ATMO_BLE_Property_Notify : 0;

	permission |= ATMO_PROPERTY(MCP9808, read) ? ATMO_BLE_Permission_Read : 0;
	permission |= ATMO_PROPERTY(MCP9808, write) ? ATMO_BLE_Permission_Write : 0;

	ATMO_DATATYPE types[3] = {ATMO_PROPERTY(MCP9808, writeDataType), ATMO_PROPERTY(MCP9808, readDataType), ATMO_PROPERTY(MCP9808, notifyDataType)};
	
	ATMO_BLE_GATTSAddCharacteristic(
		ATMO_PROPERTY(MCP9808, instance),
		&ATMO_VARIABLE(MCP9808, bleCharacteristicHandle), 
		ATMO_VARIABLE(MCP9808, bleServiceHandle), 
		ATMO_PROPERTY(MCP9808, bleCharacteristicUuid), 
		property, permission, ATMO_GetMaxValueSize(3, 64, types));
	
	ATMO_BLE_GATTSRegisterCharacteristicAbilityHandle(
		ATMO_PROPERTY(MCP9808, instance),
		ATMO_VARIABLE(MCP9808, bleCharacteristicHandle), 
		ATMO_BLE_Characteristic_Written, 
		ATMO_ABILITY(MCP9808, written));
	
	return ATMO_Status_Success;
	
}


ATMO_Status_t MCP9808_setValue(ATMO_Value_t *in, ATMO_Value_t *out) {

	
	// Convert to the desired write data type
	ATMO_Value_t convertedValue;
	ATMO_InitValue(&convertedValue);
	ATMO_CreateValueConverted(&convertedValue, ATMO_PROPERTY(MCP9808, readDataType), in);

	ATMO_BLE_GATTSSetCharacteristic(
		ATMO_PROPERTY(MCP9808, instance),
		ATMO_VARIABLE(MCP9808, bleCharacteristicHandle),
		convertedValue.size, 
		(uint8_t *)convertedValue.data,
		NULL);
	
	ATMO_FreeValue(&convertedValue);
		
	return ATMO_Status_Success;
	
}


ATMO_Status_t MCP9808_written(ATMO_Value_t *in, ATMO_Value_t *out) {

	ATMO_CreateValueConverted(out, ATMO_PROPERTY(MCP9808, writeDataType), in);
	return ATMO_Status_Success;
	
}


ATMO_Status_t MCP9808_subscibed(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t MCP9808_unsubscribed(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}

//FOOTER START

//FOOTER END

