#include "atmosphere_triggerHandler.h"
#include "atmosphere_abilityHandler.h"

#ifdef __cplusplus
	extern "C"{
#endif

void ATMO_TriggerHandler(unsigned int triggerHandleId, ATMO_Value_t *value) {
	switch(triggerHandleId) {
		case ATMO_TRIGGER(Interval, triggered):
		{
			break;
		}

		case ATMO_TRIGGER(Interval, interval):
		{
			ATMO_AbilityHandler(ATMO_ABILITY(MCP9808Temperature, readAmbientTemperature), value);
			break;
		}

		case ATMO_TRIGGER(MCP9808Temperature, triggered):
		{
			break;
		}

		case ATMO_TRIGGER(MCP9808Temperature, ambientTemperatureRead):
		{
			ATMO_AbilityHandler(ATMO_ABILITY(DebugPrint, print), value);
			ATMO_AbilityHandler(ATMO_ABILITY(MCP9808, setValue), value);
			break;
		}

		case ATMO_TRIGGER(DebugPrint, triggered):
		{
			break;
		}

		case ATMO_TRIGGER(DebugPrint, printed):
		{
			break;
		}

		case ATMO_TRIGGER(MCP9808, triggered):
		{
			break;
		}

		case ATMO_TRIGGER(MCP9808, written):
		{
			break;
		}

		case ATMO_TRIGGER(MCP9808, subscibed):
		{
			break;
		}

		case ATMO_TRIGGER(MCP9808, unsubscribed):
		{
			break;
		}

	}

}

#ifdef __cplusplus
}
#endif
