#include "atmosphere_abilityHandler.h"
#include "atmosphere_triggerHandler.h"

#ifdef __cplusplus
	extern "C"{
#endif

void ATMO_AbilityHandler(unsigned int abilityHandleId, ATMO_Value_t *value) {
	switch(abilityHandleId) {
		case ATMO_ABILITY(Interval, trigger):
		{
			ATMO_Value_t Interval_Value;
			ATMO_InitValue(&Interval_Value);
			Interval_trigger(value, &Interval_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(Interval, triggered), &Interval_Value);
			ATMO_FreeValue(&Interval_Value);
			break;
		}
		case ATMO_ABILITY(Interval, setup):
		{
			ATMO_Value_t Interval_Value;
			ATMO_InitValue(&Interval_Value);
			Interval_setup(value, &Interval_Value);
			ATMO_FreeValue(&Interval_Value);
			break;
		}
		case ATMO_ABILITY(Interval, interval):
		{
			ATMO_Value_t Interval_Value;
			ATMO_InitValue(&Interval_Value);
			Interval_interval(value, &Interval_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(Interval, interval), &Interval_Value);
			ATMO_FreeValue(&Interval_Value);
			break;
		}
		case ATMO_ABILITY(MCP9808Temperature, trigger):
		{
			ATMO_Value_t MCP9808Temperature_Value;
			ATMO_InitValue(&MCP9808Temperature_Value);
			MCP9808Temperature_trigger(value, &MCP9808Temperature_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(MCP9808Temperature, triggered), &MCP9808Temperature_Value);
			ATMO_FreeValue(&MCP9808Temperature_Value);
			break;
		}
		case ATMO_ABILITY(MCP9808Temperature, setup):
		{
			ATMO_Value_t MCP9808Temperature_Value;
			ATMO_InitValue(&MCP9808Temperature_Value);
			MCP9808Temperature_setup(value, &MCP9808Temperature_Value);
			ATMO_FreeValue(&MCP9808Temperature_Value);
			break;
		}
		case ATMO_ABILITY(MCP9808Temperature, readAmbientTemperature):
		{
			ATMO_Value_t MCP9808Temperature_Value;
			ATMO_InitValue(&MCP9808Temperature_Value);
			MCP9808Temperature_readAmbientTemperature(value, &MCP9808Temperature_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(MCP9808Temperature, ambientTemperatureRead), &MCP9808Temperature_Value);
			ATMO_FreeValue(&MCP9808Temperature_Value);
			break;
		}
		case ATMO_ABILITY(DebugPrint, trigger):
		{
			ATMO_Value_t DebugPrint_Value;
			ATMO_InitValue(&DebugPrint_Value);
			DebugPrint_trigger(value, &DebugPrint_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(DebugPrint, triggered), &DebugPrint_Value);
			ATMO_FreeValue(&DebugPrint_Value);
			break;
		}
		case ATMO_ABILITY(DebugPrint, setup):
		{
			ATMO_Value_t DebugPrint_Value;
			ATMO_InitValue(&DebugPrint_Value);
			DebugPrint_setup(value, &DebugPrint_Value);
			ATMO_FreeValue(&DebugPrint_Value);
			break;
		}
		case ATMO_ABILITY(DebugPrint, print):
		{
			ATMO_Value_t DebugPrint_Value;
			ATMO_InitValue(&DebugPrint_Value);
			DebugPrint_print(value, &DebugPrint_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(DebugPrint, printed), &DebugPrint_Value);
			ATMO_FreeValue(&DebugPrint_Value);
			break;
		}
		case ATMO_ABILITY(MCP9808, trigger):
		{
			ATMO_Value_t MCP9808_Value;
			ATMO_InitValue(&MCP9808_Value);
			MCP9808_trigger(value, &MCP9808_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(MCP9808, triggered), &MCP9808_Value);
			ATMO_FreeValue(&MCP9808_Value);
			break;
		}
		case ATMO_ABILITY(MCP9808, setup):
		{
			ATMO_Value_t MCP9808_Value;
			ATMO_InitValue(&MCP9808_Value);
			MCP9808_setup(value, &MCP9808_Value);
			ATMO_FreeValue(&MCP9808_Value);
			break;
		}
		case ATMO_ABILITY(MCP9808, setValue):
		{
			ATMO_Value_t MCP9808_Value;
			ATMO_InitValue(&MCP9808_Value);
			MCP9808_setValue(value, &MCP9808_Value);
			ATMO_FreeValue(&MCP9808_Value);
			break;
		}
		case ATMO_ABILITY(MCP9808, written):
		{
			ATMO_Value_t MCP9808_Value;
			ATMO_InitValue(&MCP9808_Value);
			MCP9808_written(value, &MCP9808_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(MCP9808, written), &MCP9808_Value);
			ATMO_FreeValue(&MCP9808_Value);
			break;
		}
		case ATMO_ABILITY(MCP9808, subscibed):
		{
			ATMO_Value_t MCP9808_Value;
			ATMO_InitValue(&MCP9808_Value);
			MCP9808_subscibed(value, &MCP9808_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(MCP9808, subscibed), &MCP9808_Value);
			ATMO_FreeValue(&MCP9808_Value);
			break;
		}
		case ATMO_ABILITY(MCP9808, unsubscribed):
		{
			ATMO_Value_t MCP9808_Value;
			ATMO_InitValue(&MCP9808_Value);
			MCP9808_unsubscribed(value, &MCP9808_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(MCP9808, unsubscribed), &MCP9808_Value);
			ATMO_FreeValue(&MCP9808_Value);
			break;
		}
	}

}

#ifdef __cplusplus
}
#endif
