
#ifndef ATMO_PROPERTIES_H
#define ATMO_PROPERTIES_H

#ifdef __cplusplus
	extern "C"{
#endif

#define ATMO_PROPERTY(ELEMENT, NAME) ATMO_ ## ELEMENT ## _PROPERTY_  ## NAME

#define ATMO_Interval_PROPERTY_errorData NULL
#define ATMO_Interval_PROPERTY_codeUserChanged NULL
#define ATMO_Interval_PROPERTY_instance ATMO_DRIVERINSTANCE_INTERVAL_INTERVAL1
#define ATMO_Interval_PROPERTY_time 1000

#define ATMO_MCP9808Temperature_PROPERTY_errorData NULL
#define ATMO_MCP9808Temperature_PROPERTY_codeUserChanged NULL
#define ATMO_MCP9808Temperature_PROPERTY_i2cInstance ATMO_DRIVERINSTANCE_I2C_I2C1
#define ATMO_MCP9808Temperature_PROPERTY_i2cAddress 0x18

#define ATMO_DebugPrint_PROPERTY_errorData NULL
#define ATMO_DebugPrint_PROPERTY_codeUserChanged NULL
#define ATMO_DebugPrint_PROPERTY_prepend ""

#define ATMO_MCP9808_PROPERTY_errorData NULL
#define ATMO_MCP9808_PROPERTY_codeUserChanged NULL
#define ATMO_MCP9808_PROPERTY_instance ATMO_DRIVERINSTANCE_BLE_BLE1
#define ATMO_MCP9808_PROPERTY_bleServiceUuid "adab23d7-9188-4841-9376-4d0208fe775c"
#define ATMO_MCP9808_PROPERTY_bleCharacteristicUuid "adab23d7-9188-4841-9376-4d0208fe775d"
#define ATMO_MCP9808_PROPERTY_read true
#define ATMO_MCP9808_PROPERTY_write true
#define ATMO_MCP9808_PROPERTY_notify false
#define ATMO_MCP9808_PROPERTY_readDataType ATMO_DATATYPE_FLOAT
#define ATMO_MCP9808_PROPERTY_writeDataType ATMO_DATATYPE_FLOAT
#define ATMO_MCP9808_PROPERTY_notifyDataType ATMO_DATATYPE_FLOAT


#ifdef __cplusplus
}
#endif

#endif
