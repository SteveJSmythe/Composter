
#ifndef ATMO_CALLBACKS_H
#define ATMO_CALLBACKS_H

#include "atmosphere_platform.h"
#include "atmosphere_properties.h"
#include "atmosphere_variables.h"
#include "atmosphere_triggerHandler.h"
#include "atmosphere_interruptsHandler.h"
#include "atmosphere_embedded_libraries.h"
#include "atmosphere_abilityHandler.h"

#include "atmosphere_driverinstance.h"

#include "atmosphere_cloudcommands.h"

#include "atmosphere_elementnames.h"

#define ATMO_CALLBACK(ELEMENT, NAME) ELEMENT ## _ ## NAME

void ATMO_Setup();

ATMO_Status_t Interval_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t Interval_setup(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t Interval_interval(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t MCP9808Temperature_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t MCP9808Temperature_setup(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t MCP9808Temperature_readAmbientTemperature(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t DebugPrint_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t DebugPrint_setup(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t DebugPrint_print(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t MCP9808_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t MCP9808_setup(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t MCP9808_setValue(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t MCP9808_written(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t MCP9808_subscibed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t MCP9808_unsubscribed(ATMO_Value_t *in, ATMO_Value_t *out);
#endif
