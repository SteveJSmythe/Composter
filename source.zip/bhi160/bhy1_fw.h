#ifndef BHY1_FIRMWARE_H_
#define BHY1_FIRMWARE_H_

extern const unsigned char bhy1_fw[];

#endif /* BHY1_FIRMWARE_H_ */
