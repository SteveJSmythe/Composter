#include "mcp9808.h"
#include "../i2c/i2c.h"

static ATMO_BOOL_t _ATMO_MCP9808_Initialized = false;
static ATMO_DriverInstanceHandle_t _ATMO_MCP9808_I2CInstance = 0;
static uint8_t _ATMO_MCP9808_Addr = 0;

#define MCP9808_REG_CONFIG 0x01 ///< MCP9808 config register

#define MCP9808_REG_CONFIG_SHUTDOWN 0x0100   ///< shutdown config
#define MCP9808_REG_CONFIG_CRITLOCKED 0x0080 ///< critical trip lock
#define MCP9808_REG_CONFIG_WINLOCKED 0x0040  ///< alarm window lock
#define MCP9808_REG_CONFIG_INTCLR 0x0020     ///< interrupt clear
#define MCP9808_REG_CONFIG_ALERTSTAT 0x0010  ///< alert output status
#define MCP9808_REG_CONFIG_ALERTCTRL 0x0008  ///< alert output control
#define MCP9808_REG_CONFIG_ALERTSEL 0x0004   ///< alert output select
#define MCP9808_REG_CONFIG_ALERTPOL 0x0002   ///< alert output polarity
#define MCP9808_REG_CONFIG_ALERTMODE 0x0001  ///< alert output mode

#define MCP9808_REG_UPPER_TEMP 0x02   ///< upper alert boundary
#define MCP9808_REG_LOWER_TEMP 0x03   ///< lower alert boundery
#define MCP9808_REG_CRIT_TEMP 0x04    ///< critical temperature
#define MCP9808_REG_AMBIENT_TEMP 0x05 ///< ambient temperature
#define MCP9808_REG_MANUF_ID 0x06     ///< manufacture ID
#define MCP9808_REG_DEVICE_ID 0x07    ///< device ID
#define MCP9808_REG_RESOLUTION 0x08   ///< resolutin

static ATMO_BOOL_t _ATMO_MCP9808_Read2ByteReg(uint8_t regAddr, uint16_t *data)
{
    uint8_t val[2] = {0};

    ATMO_I2C_Status_t status = ATMO_I2C_MasterRead(_ATMO_MCP9808_I2CInstance, _ATMO_MCP9808_Addr, &regAddr, 1, (uint8_t *)val, 2, 1000);

    if(status != ATMO_I2C_Status_Success)
    {
        return false;
    }

    (*data) = ((uint16_t)val[0]) << 8 | val[1]; // Swap the bytes

    return true;
}

static ATMO_BOOL_t _ATMO_MCP9808_Write2ByteReg(uint8_t regAddr, uint16_t data)
{
    uint8_t writeData[2] = {((data >> 8) & 0xFF),  ((data & 0xFF) << 8)};

    ATMO_I2C_Status_t status = ATMO_I2C_MasterWrite(_ATMO_MCP9808_I2CInstance, _ATMO_MCP9808_Addr, &regAddr, 1, (uint8_t *)writeData, 2, 1000);

    return status == ATMO_I2C_Status_Success;
}

ATMO_BOOL_t ATMO_MCP9808_Init(ATMO_DriverInstanceHandle_t i2cHandle, uint8_t i2cAddr)
{
    _ATMO_MCP9808_I2CInstance = i2cHandle;
    _ATMO_MCP9808_Addr = i2cAddr;

    uint16_t manufId = 0;
    if (!_ATMO_MCP9808_Read2ByteReg(MCP9808_REG_MANUF_ID, &manufId))
    {
        ATMO_PLATFORM_DebugPrint("Error reading Man Id\r\n");
        return false;
    }

    if (manufId != 0x0054)
    {
        ATMO_PLATFORM_DebugPrint("Manufacturer ID Mismtach (Rcv %04X Expect %04X)\r\n", manufId, 0x0054);
        return false;
    }

    uint16_t devId = 0;
    if (!_ATMO_MCP9808_Read2ByteReg(MCP9808_REG_DEVICE_ID, &devId))
    {
        ATMO_PLATFORM_DebugPrint("Error reading Dev Id\r\n");
        return false;
    }

    if (devId != 0x0400)
    {
        ATMO_PLATFORM_DebugPrint("Dev ID Mismtach (Rcv %04X Expect %04X)\r\n", devId, 0x0400);
        return false;
    }

    if (!_ATMO_MCP9808_Write2ByteReg(MCP9808_REG_CONFIG, 0x0))
    {
        ATMO_PLATFORM_DebugPrint("Error writing config\r\n");
        return false;
    }

    _ATMO_MCP9808_Initialized = true;
    return true;
}

ATMO_BOOL_t ATMO_MCP9808_ReadTemperature(float *temperatureC)
{
    if (!_ATMO_MCP9808_Initialized)
    {
        return false;
    }

    uint16_t rawTemp = 0;
    if (!_ATMO_MCP9808_Read2ByteReg(MCP9808_REG_AMBIENT_TEMP, &rawTemp))
    {
        return false;
    }

    // From https://github.com/adafruit/Adafruit_MCP9808_Library/blob/master/Adafruit_MCP9808.cpp
    float temp = rawTemp & 0x0FFF;
    temp /= 16.0;
    if (rawTemp & 0x1000)
    {
        temp -= 256;
    }

    *temperatureC = temp;
    
    return true;
}