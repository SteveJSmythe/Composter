#ifndef __ATMO_MCP9808_H_
#define __ATMO_MCP9808_H_

#include "../atmo/core.h"
#include "../app_src/atmosphere_platform.h"

ATMO_BOOL_t ATMO_MCP9808_Init(ATMO_DriverInstanceHandle_t i2cHandle, uint8_t i2cAddr);

ATMO_BOOL_t ATMO_MCP9808_ReadTemperature(float *temperatureC);

#endif