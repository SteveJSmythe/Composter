#ifndef ATMO_STRTOF_H_
#define ATMO_STRTOF_H_

float ATMO_Strtof(const char *str);

#endif